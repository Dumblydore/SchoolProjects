package medwards11.politician;

/**
 * Created by Maurice on 12/9/2014.
 */
public class Stance {
    public static String[] getStances() {
        String[] out = {"Region","PoliticianName","Party","HouseSeat","ContactNumber","Email","Abortion","Budget_and_Economy","Civil_Rights","Corporations","Crime","Drugs","Education","Energy_and_Oil","Environment","Families_and_Children","Foreign_Policy","Free_Trade","Government_Reform","Gun_Control","Health_Care","Homeland_Security","Immigration","Jobs","Principles_and_Values","Social_Security","Tax_Reform","Technology","War_and_Peace","Welfare_and_Poverty"};
        return out;
    }
}
